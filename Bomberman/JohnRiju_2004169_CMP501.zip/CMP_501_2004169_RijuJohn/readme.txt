1. Run the server and copy the ip address that server sends
2. Run the client and enter the ip address to connect to as well as your name

Movement Controls:
W A S D - Up, Down, Left, Right movements
Space - Place bomb in own grid
P - Place special bombs in all connected opponent grids

All bombs explode in a one block radius only
Normal bombs explode in player's own grid
Special bombs do not explode in player's own grid and does not break any walls or kill self

Goal is to kill all other connected players

Link to DEMO video:
https://web.microsoftstream.com/video/79a108f6-d51f-45ce-8933-d489d542cf76?list=studio